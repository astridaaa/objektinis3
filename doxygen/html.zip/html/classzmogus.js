var classzmogus =
[
    [ "zmogus", "classzmogus.html#a3cb03824ec8269cf401cbf615e440833", null ],
    [ "zmogus", "classzmogus.html#a1072ddfb5c999ee06724e6186ac2b432", null ],
    [ "~zmogus", "classzmogus.html#a67d08c33049ff379f5c8b72745416239", null ],
    [ "zmogus", "classzmogus.html#ab6b718417f4c56bbad48ae631c18c174", null ],
    [ "getPavarde", "classzmogus.html#a5dfb525146fe08355f3e4aae7357c5da", null ],
    [ "getVardas", "classzmogus.html#a1c16f5d3a776dd517d3b6c3a2244d49f", null ],
    [ "operator=", "classzmogus.html#ad0adf89430e25e71de1b3a6c1d4d53d7", null ],
    [ "setPavarde", "classzmogus.html#ab04e8e560de456f3d864e8c4d1611606", null ],
    [ "setVardas", "classzmogus.html#a5e58cd0e8087cbe81c82f96befff608a", null ],
    [ "pavarde", "classzmogus.html#ae57250d8b5eec99e78c5bae3a0ab1856", null ],
    [ "vardas", "classzmogus.html#ab79ef7e33cb25ed93458a93f49579d34", null ]
];