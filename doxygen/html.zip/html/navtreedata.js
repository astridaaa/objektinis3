/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Objektinis Programavimas", "index.html", [
    [ "OOP", "md__r_e_a_d_m_e.html", [
      [ "Kompiuterio specifikacijos", "md__r_e_a_d_m_e.html#autotoc_md1", null ],
      [ "Naudojimosi instrukcija:", "md__r_e_a_d_m_e.html#autotoc_md2", null ],
      [ "Programos aprašas:", "md__r_e_a_d_m_e.html#autotoc_md3", [
        [ "v1.5 versija | abstrakti klasė", "md__r_e_a_d_m_e.html#autotoc_md4", null ],
        [ "v1.2 versija | rule of five ir įvesties/išvesties operatorių implementacija", "md__r_e_a_d_m_e.html#autotoc_md5", null ],
        [ "v1.1 versija | klasių implementacija", "md__r_e_a_d_m_e.html#autotoc_md6", null ],
        [ "v0.4 implementacija naudojant funkcijų šablonus", "md__r_e_a_d_m_e.html#autotoc_md7", null ]
      ] ],
      [ "Strategijų aprašymai:", "md__r_e_a_d_m_e.html#autotoc_md9", null ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Variables", "functions_vars.html", null ],
        [ "Related Symbols", "functions_rela.html", null ]
      ] ]
    ] ],
    [ "Files", "files.html", [
      [ "File List", "files.html", "files_dup" ],
      [ "File Members", "globals.html", [
        [ "All", "globals.html", null ],
        [ "Functions", "globals_func.html", null ],
        [ "Typedefs", "globals_type.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"_strategija1_8cpp.html"
];

var SYNCONMSG = 'click to disable panel synchronization';
var SYNCOFFMSG = 'click to enable panel synchronization';