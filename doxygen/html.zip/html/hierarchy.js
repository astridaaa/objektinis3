var hierarchy =
[
    [ "Vector< T >", "class_vector.html", null ],
    [ "zmogus", "classzmogus.html", [
      [ "Stud", "class_stud.html", null ]
    ] ]
];