var annotated_dup =
[
    [ "Stud", "class_stud.html", "class_stud" ],
    [ "Vector", "class_vector.html", "class_vector" ],
    [ "zmogus", "classzmogus.html", "classzmogus" ]
];