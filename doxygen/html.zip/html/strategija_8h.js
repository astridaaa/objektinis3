var strategija_8h =
[
    [ "nuskaitymasFile", "strategija_8h.html#a7f729c5964ed35cfaa056b2880a480e5", null ],
    [ "studentuIsskirstymas", "strategija_8h.html#a5c4a8a2bb187d75edc31f9fdbc40e377", null ],
    [ "studentuIsskirstymas2", "strategija_8h.html#a1b26ea3f4f23897e0e78fd70ccb5c02c", null ],
    [ "studentuRusiavimas", "strategija_8h.html#a1442771388f51c37209874133ece4b08", null ],
    [ "studentuRusiavimas2", "strategija_8h.html#af32498633e9d54d4218649c0718cc630", null ],
    [ "StudentuRusiavimas3", "strategija_8h.html#a8ad81bb81af515f9cf92d1d722d1974f", null ],
    [ "studentuSkirstymas3", "strategija_8h.html#a97379dcf2a7c5575cb3e9b3765018a31", null ],
    [ "testavimasPrint", "strategija_8h.html#a67b1666e8d389968693d79dc044aeadf", null ],
    [ "vykdomaPrograma", "strategija_8h.html#a8048ac7abc01478b3b466d3e037353e7", null ],
    [ "vykdomaPrograma2", "strategija_8h.html#abdd483e4b0efd91fe7438c8ae11fe5f1", null ],
    [ "vykdomaPrograma3", "strategija_8h.html#a2037b5d9d75ed4b2bbec8ffad6330563", null ]
];