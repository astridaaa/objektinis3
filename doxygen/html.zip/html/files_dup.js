var files_dup =
[
    [ "functions.cpp", "functions_8cpp.html", "functions_8cpp" ],
    [ "functions.h", "functions_8h.html", "functions_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "main.h", "main_8h.html", "main_8h" ],
    [ "strategija.h", "strategija_8h.html", "strategija_8h" ],
    [ "Strategija1.cpp", "_strategija1_8cpp.html", "_strategija1_8cpp" ],
    [ "Strategija2.cpp", "_strategija2_8cpp.html", "_strategija2_8cpp" ],
    [ "Strategija3.cpp", "_strategija3_8cpp.html", "_strategija3_8cpp" ]
];