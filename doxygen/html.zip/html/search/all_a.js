var searchData=
[
  ['nuskaitymasfile_0',['nuskaitymasFile',['../strategija_8h.html#a7f729c5964ed35cfaa056b2880a480e5',1,'strategija.h']]]
];
