var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_stud.html#aa3494bef68f411f5285768f119043527',1,'Stud']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_stud.html#a99c1cdbb0f0dfccfa6021b8a10757163',1,'Stud']]]
];
