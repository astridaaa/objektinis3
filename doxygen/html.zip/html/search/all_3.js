var searchData=
[
  ['5_20versija_20abstrakti_20klasė_0',['v1.5 versija | abstrakti klasė',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]]
];
