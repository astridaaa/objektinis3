var indexSectionsWithContent =
{
  0: "abcdefgikmnoprstuvz~",
  1: "svz",
  2: "fmsuv",
  3: "abcdefgikmnoprstvz~",
  4: "pv",
  5: "k",
  6: "o",
  7: "c"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends",
  7: "Macros"
};

