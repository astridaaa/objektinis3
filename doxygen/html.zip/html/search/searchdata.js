var indexSectionsWithContent =
{
  0: "1245acdfgikmnoprstvz~įš",
  1: "sz",
  2: "fmrs",
  3: "cdfgikmnoprstvz~",
  4: "pv",
  5: "k",
  6: "o",
  7: "o"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "related",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Friends",
  7: "Pages"
};

