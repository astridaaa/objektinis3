var searchData=
[
  ['vardai_0',['vardai',['../functions_8cpp.html#aa1d7b3709717e4f95c7db3b57fe520fc',1,'vardai(Stud &amp;studentas, string &amp;ss):&#160;functions.cpp'],['../functions_8h.html#aa1d7b3709717e4f95c7db3b57fe520fc',1,'vardai(Stud &amp;studentas, string &amp;ss):&#160;functions.cpp']]],
  ['vector_1',['Vector',['../class_vector.html#a39d6069675db4ecfc1ab81d440da759a',1,'Vector::Vector()'],['../class_vector.html#ad667632b968d0cd366043da554a2a03f',1,'Vector::Vector(size_t Size)'],['../class_vector.html#a0dba46f864a228e2abde110db8a4e4d8',1,'Vector::Vector(std::initializer_list&lt; T &gt; list)'],['../class_vector.html#a83ed77764ab028ba5f5177a5926effa7',1,'Vector::Vector(const Vector &amp;v)'],['../class_vector.html#a278998a66b1c2cc80497da843847e41c',1,'Vector::Vector(Vector &amp;&amp;v)']]],
  ['vectoridejimas_2',['vectorIdejimas',['../functions_8h.html#ad5e392faf0090c26cdcbf70e7425b36f',1,'functions.h']]],
  ['vykdomaprograma_3',['vykdomaPrograma',['../strategija_8h.html#a8048ac7abc01478b3b466d3e037353e7',1,'strategija.h']]],
  ['vykdomaprograma2_4',['vykdomaPrograma2',['../strategija_8h.html#abdd483e4b0efd91fe7438c8ae11fe5f1',1,'strategija.h']]],
  ['vykdomaprograma3_5',['vykdomaPrograma3',['../strategija_8h.html#a2037b5d9d75ed4b2bbec8ffad6330563',1,'strategija.h']]]
];
