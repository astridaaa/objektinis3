var searchData=
[
  ['konstruktoriutest_0',['konstruktoriuTest',['../functions_8cpp.html#a58e502b98dee11428f08f82148277595',1,'konstruktoriuTest():&#160;functions.cpp'],['../functions_8h.html#a58e502b98dee11428f08f82148277595',1,'konstruktoriuTest():&#160;functions.cpp']]]
];
