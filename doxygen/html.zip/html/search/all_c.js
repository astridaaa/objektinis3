var searchData=
[
  ['naudojant_20funkcijų_20šablonus_0',['v0.4 implementacija naudojant funkcijų šablonus',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]],
  ['naudojimosi_20instrukcija_3a_1',['Naudojimosi instrukcija:',['../md__r_e_a_d_m_e.html#autotoc_md2',1,'']]],
  ['nuskaitymasfile_2',['nuskaitymasFile',['../strategija_8h.html#a2577019d12aa0f99122ed2514c3042bd',1,'strategija.h']]]
];
