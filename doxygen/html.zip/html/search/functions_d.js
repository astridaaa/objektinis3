var searchData=
[
  ['vardai_0',['vardai',['../functions_8cpp.html#aa1d7b3709717e4f95c7db3b57fe520fc',1,'vardai(Stud &amp;studentas, string &amp;ss):&#160;functions.cpp'],['../functions_8h.html#aa1d7b3709717e4f95c7db3b57fe520fc',1,'vardai(Stud &amp;studentas, string &amp;ss):&#160;functions.cpp']]],
  ['vectoridejimas_1',['vectorIdejimas',['../functions_8h.html#ad5e392faf0090c26cdcbf70e7425b36f',1,'functions.h']]],
  ['vykdomaprograma_2',['vykdomaPrograma',['../strategija_8h.html#a8048ac7abc01478b3b466d3e037353e7',1,'strategija.h']]],
  ['vykdomaprograma2_3',['vykdomaPrograma2',['../strategija_8h.html#abdd483e4b0efd91fe7438c8ae11fe5f1',1,'strategija.h']]],
  ['vykdomaprograma3_4',['vykdomaPrograma3',['../strategija_8h.html#a64351a3068b8e7272f380ede47ef09d7',1,'strategija.h']]]
];
