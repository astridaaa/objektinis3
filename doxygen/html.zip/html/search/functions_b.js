var searchData=
[
  ['setbalasgalutinisvid_0',['setBalasGalutinisVid',['../class_stud.html#a9f4c97bb8b32e7376c3bc46965070151',1,'Stud']]],
  ['setegzaminas_1',['setEgzaminas',['../class_stud.html#a3422f3840e7d7f73285aed6b1b285a75',1,'Stud']]],
  ['setnd_2',['setND',['../class_stud.html#ab94919093ee88ab7cf4a7a67487775bc',1,'Stud']]],
  ['setpavarde_3',['setPavarde',['../classzmogus.html#ab04e8e560de456f3d864e8c4d1611606',1,'zmogus::setPavarde()'],['../class_stud.html#a56713193f9e5f17867cd9c0392f4e363',1,'Stud::setPavarde()']]],
  ['setvardas_4',['setVardas',['../classzmogus.html#a5e58cd0e8087cbe81c82f96befff608a',1,'zmogus::setVardas()'],['../class_stud.html#ab60e49d4ff2c05253056a9a0419db714',1,'Stud::setVardas(const string &amp;var) override']]],
  ['stud_5',['Stud',['../class_stud.html#a97585839898d45dc9fc815d5b36e2b69',1,'Stud::Stud()'],['../class_stud.html#a465ac7efc65a2f9b5737801e0e632c19',1,'Stud::Stud(const string &amp;vrd, const string &amp;pvrd, int egzam, const vector&lt; int &gt; &amp;namud)'],['../class_stud.html#af2451599b5678bdf816d5548bdc47870',1,'Stud::Stud(const Stud &amp;studCopy)'],['../class_stud.html#a326af0eef8f143d8cc00ff263abba800',1,'Stud::Stud(Stud &amp;&amp;studMove)']]],
  ['studentuisskirstymas_6',['studentuIsskirstymas',['../strategija_8h.html#a5c4a8a2bb187d75edc31f9fdbc40e377',1,'strategija.h']]],
  ['studentuisskirstymas2_7',['studentuIsskirstymas2',['../strategija_8h.html#a1b26ea3f4f23897e0e78fd70ccb5c02c',1,'strategija.h']]],
  ['studenturusiavimas_8',['studentuRusiavimas',['../strategija_8h.html#a1442771388f51c37209874133ece4b08',1,'strategija.h']]],
  ['studenturusiavimas2_9',['studentuRusiavimas2',['../strategija_8h.html#af32498633e9d54d4218649c0718cc630',1,'strategija.h']]],
  ['studenturusiavimas3_10',['StudentuRusiavimas3',['../strategija_8h.html#ad151477abd1e8ef0ef8ddbe5df889445',1,'strategija.h']]],
  ['studentuskirstymas3_11',['studentuSkirstymas3',['../strategija_8h.html#a6a419c5b53b593d40cd74d29c8aba89a',1,'strategija.h']]]
];
