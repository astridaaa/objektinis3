var searchData=
[
  ['galutinis_0',['galutinis',['../class_stud.html#a8e71b5bf996facb91c2eaa8ebbed59c3',1,'Stud']]],
  ['galutinisbalas_1',['galutinisBalas',['../class_stud.html#a820fb08df8ccbf2ca8a4ed93745161ee',1,'Stud']]],
  ['generuotifiles_2',['GeneruotiFiles',['../functions_8cpp.html#a393fb17a37377eadfb5c0791e9967f3a',1,'GeneruotiFiles(int StudSkaicius):&#160;functions.cpp'],['../functions_8h.html#a393fb17a37377eadfb5c0791e9967f3a',1,'GeneruotiFiles(int StudSkaicius):&#160;functions.cpp']]],
  ['getegzaminas_3',['getEgzaminas',['../class_stud.html#a9997b21b5a5369e79c9956c651d27f0b',1,'Stud']]],
  ['getnd_4',['getND',['../class_stud.html#a790d930ed911b7adde647962712e88e8',1,'Stud']]],
  ['getpavarde_5',['getPavarde',['../classzmogus.html#a5dfb525146fe08355f3e4aae7357c5da',1,'zmogus']]],
  ['getpaz_6',['getPaz',['../class_stud.html#af2e0c612c3e0d3971301bff9e400c522',1,'Stud']]],
  ['getvardas_7',['getVardas',['../classzmogus.html#a1c16f5d3a776dd517d3b6c3a2244d49f',1,'zmogus']]],
  ['grazintipaskutini_8',['grazintiPaskutini',['../class_stud.html#a4b66c2fb5021c4690335ea12dba6fe85',1,'Stud']]]
];
