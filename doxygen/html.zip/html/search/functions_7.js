var searchData=
[
  ['nuskaitymasfile_0',['nuskaitymasFile',['../strategija_8h.html#a2577019d12aa0f99122ed2514c3042bd',1,'strategija.h']]]
];
