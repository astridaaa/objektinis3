var searchData=
[
  ['2_20versija_20rule_20of_20five_20ir_20įvesties_20išvesties_20operatorių_20implementacija_0',['v1.2 versija | rule of five ir įvesties/išvesties operatorių implementacija',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]]
];
