var searchData=
[
  ['abstrakti_20klasė_0',['v1.5 versija | abstrakti klasė',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['aprašas_3a_1',['Programos aprašas:',['../md__r_e_a_d_m_e.html#autotoc_md3',1,'']]],
  ['aprašymai_3a_2',['Strategijų aprašymai:',['../md__r_e_a_d_m_e.html#autotoc_md9',1,'']]]
];
