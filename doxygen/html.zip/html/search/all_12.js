var searchData=
[
  ['v0_204_20implementacija_20naudojant_20funkcijų_20šablonus_0',['v0.4 implementacija naudojant funkcijų šablonus',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]],
  ['v1_201_20versija_20klasių_20implementacija_1',['v1.1 versija | klasių implementacija',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['v1_202_20versija_20rule_20of_20five_20ir_20įvesties_20išvesties_20operatorių_20implementacija_2',['v1.2 versija | rule of five ir įvesties/išvesties operatorių implementacija',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['v1_205_20versija_20abstrakti_20klasė_3',['v1.5 versija | abstrakti klasė',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['vardai_4',['vardai',['../functions_8cpp.html#aa1d7b3709717e4f95c7db3b57fe520fc',1,'vardai(Stud &amp;studentas, string &amp;ss):&#160;functions.cpp'],['../functions_8h.html#aa1d7b3709717e4f95c7db3b57fe520fc',1,'vardai(Stud &amp;studentas, string &amp;ss):&#160;functions.cpp']]],
  ['vardas_5',['vardas',['../classzmogus.html#ab79ef7e33cb25ed93458a93f49579d34',1,'zmogus']]],
  ['vectoridejimas_6',['vectorIdejimas',['../functions_8h.html#ad5e392faf0090c26cdcbf70e7425b36f',1,'functions.h']]],
  ['versija_20abstrakti_20klasė_7',['v1.5 versija | abstrakti klasė',['../md__r_e_a_d_m_e.html#autotoc_md4',1,'']]],
  ['versija_20klasių_20implementacija_8',['v1.1 versija | klasių implementacija',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]],
  ['versija_20rule_20of_20five_20ir_20įvesties_20išvesties_20operatorių_20implementacija_9',['v1.2 versija | rule of five ir įvesties/išvesties operatorių implementacija',['../md__r_e_a_d_m_e.html#autotoc_md5',1,'']]],
  ['vykdomaprograma_10',['vykdomaPrograma',['../strategija_8h.html#a8048ac7abc01478b3b466d3e037353e7',1,'strategija.h']]],
  ['vykdomaprograma2_11',['vykdomaPrograma2',['../strategija_8h.html#abdd483e4b0efd91fe7438c8ae11fe5f1',1,'strategija.h']]],
  ['vykdomaprograma3_12',['vykdomaPrograma3',['../strategija_8h.html#a64351a3068b8e7272f380ede47ef09d7',1,'strategija.h']]]
];
