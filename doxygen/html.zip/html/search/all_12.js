var searchData=
[
  ['zmogus_0',['zmogus',['../classzmogus.html',1,'zmogus'],['../classzmogus.html#a3cb03824ec8269cf401cbf615e440833',1,'zmogus::zmogus()'],['../classzmogus.html#a1072ddfb5c999ee06724e6186ac2b432',1,'zmogus::zmogus(const string &amp;var, const string &amp;pav)'],['../classzmogus.html#ab6b718417f4c56bbad48ae631c18c174',1,'zmogus::zmogus(zmogus &amp;&amp;z)']]]
];
