var searchData=
[
  ['rbegin_0',['rbegin',['../class_vector.html#a614448e9aca6f7d9e2c788e87ea142d7',1,'Vector']]],
  ['removelast_1',['removeLast',['../class_stud.html#a21604bd6f368e705055dcdc4d318acd5',1,'Stud']]],
  ['removend_2',['removeND',['../class_stud.html#ab4685ba6234f94fb98a74d03bb698c20',1,'Stud']]],
  ['rend_3',['rend',['../class_vector.html#a8c9f1f9612dff2d18dde206b6d2d31e4',1,'Vector']]],
  ['reserve_4',['reserve',['../class_vector.html#a8af14310697b99ac1ece6368c0ac0559',1,'Vector']]],
  ['resize_5',['resize',['../class_vector.html#a32719c93bf7328bc97bbdf191457c0c6',1,'Vector::resize(size_t newCap)'],['../class_vector.html#aed582e3ab04fb041ccd4d86e0607a481',1,'Vector::resize(size_t newCap, const T &amp;element)']]]
];
