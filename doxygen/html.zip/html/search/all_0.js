var searchData=
[
  ['1_20versija_20klasių_20implementacija_0',['v1.1 versija | klasių implementacija',['../md__r_e_a_d_m_e.html#autotoc_md6',1,'']]]
];
