var searchData=
[
  ['_7estud_0',['~Stud',['../class_stud.html#a72960a8e63582a74964f2efbdeda4deb',1,'Stud']]],
  ['_7evector_1',['~Vector',['../class_vector.html#afd524fac19e6d3d69db5198ffe2952b0',1,'Vector']]],
  ['_7ezmogus_2',['~zmogus',['../classzmogus.html#a67d08c33049ff379f5c8b72745416239',1,'zmogus']]]
];
