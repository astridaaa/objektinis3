var searchData=
[
  ['4_20implementacija_20naudojant_20funkcijų_20šablonus_0',['v0.4 implementacija naudojant funkcijų šablonus',['../md__r_e_a_d_m_e.html#autotoc_md7',1,'']]]
];
