var searchData=
[
  ['removelast_0',['removeLast',['../class_stud.html#a21604bd6f368e705055dcdc4d318acd5',1,'Stud']]],
  ['removend_1',['removeND',['../class_stud.html#ab4685ba6234f94fb98a74d03bb698c20',1,'Stud']]]
];
